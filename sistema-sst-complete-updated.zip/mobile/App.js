import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  Alert,
  ScrollView,
  Linking,
} from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import jwtDecode from 'jwt-decode';

// URL base de la API. Ajuste según su entorno (simulador o dispositivo físico).
const API_BASE_URL = 'http://localhost:3001';

export default function App() {
  const [token, setToken] = useState(null);
  const [refreshToken, setRefreshToken] = useState(null);
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [plate, setPlate] = useState('');
  const [notes, setNotes] = useState('');
  const [accDescription, setAccDescription] = useState('');
  const [accSeverity, setAccSeverity] = useState('');
  const [accidents, setAccidents] = useState([]);

  // Timer ID for scheduled refresh
  let refreshTimer = null;

  useEffect(() => {
    // Load tokens stored when app starts
    const loadTokens = async () => {
      const storedToken = await AsyncStorage.getItem('token');
      const storedRefresh = await AsyncStorage.getItem('refreshToken');
      if (storedToken && storedRefresh) {
        setToken(storedToken);
        setRefreshToken(storedRefresh);
        try {
          const decoded = jwtDecode(storedToken);
          setUser(decoded);
        } catch (err) {
          await AsyncStorage.removeItem('token');
          await AsyncStorage.removeItem('refreshToken');
        }
      }
    };
    loadTokens();
  }, []);

  // Fetch accidents list for PDF links
  useEffect(() => {
    if (token) {
      const fetchAccidents = async () => {
        try {
          const res = await axios.get(`${API_BASE_URL}/api/accidents?limit=10&offset=0`);
          setAccidents(res.data || []);
        } catch (err) {
          setAccidents([]);
        }
      };
      fetchAccidents();
    }
  }, [token]);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Validación', 'Ingrese correo y contraseña');
      return;
    }
    try {
      const res = await axios.post(`${API_BASE_URL}/api/auth/login`, { email, password });
      const receivedToken = res.data.token;
      const receivedRefresh = res.data.refreshToken;
      await AsyncStorage.setItem('token', receivedToken);
      await AsyncStorage.setItem('refreshToken', receivedRefresh);
      setToken(receivedToken);
      setRefreshToken(receivedRefresh);
      try {
        const decoded = jwtDecode(receivedToken);
        setUser(decoded);
      } catch {}
      setEmail('');
      setPassword('');
      scheduleRefresh(receivedToken, receivedRefresh);
    } catch (err) {
      Alert.alert('Error', err.response?.data?.message || 'No se pudo iniciar sesión');
    }
  };

  // Refresh token rotation
  const refreshTokens = async () => {
    if (!refreshToken) return;
    try {
      const res = await axios.post(`${API_BASE_URL}/api/auth/refresh`, {
        refreshToken: refreshToken,
      });
      const newAccess = res.data.token;
      const newRefresh = res.data.refreshToken;
      await AsyncStorage.setItem('token', newAccess);
      await AsyncStorage.setItem('refreshToken', newRefresh);
      setToken(newAccess);
      setRefreshToken(newRefresh);
      try {
        const decoded = jwtDecode(newAccess);
        setUser(decoded);
      } catch {}
      scheduleRefresh(newAccess, newRefresh);
    } catch {
      await logout();
    }
  };

  // Schedule a token refresh before expiration. Cancels any existing timer.
  const scheduleRefresh = (access, refresh) => {
    // Clear previous timer if exists
    if (refreshTimer) {
      clearTimeout(refreshTimer);
    }
    try {
      const decoded = jwtDecode(access);
      const exp = decoded.exp * 1000;
      const now = Date.now();
      let delay = exp - now - 60000; // 1 minute before
      if (delay < 0) delay = 0;
      refreshTimer = setTimeout(() => {
        refreshTokens();
      }, delay);
    } catch {}
  };

  const logout = async () => {
    const currentRefresh = await AsyncStorage.getItem('refreshToken');
    await AsyncStorage.removeItem('token');
    await AsyncStorage.removeItem('refreshToken');
    setToken(null);
    setRefreshToken(null);
    setUser(null);
    // Cancel scheduled refresh
    if (refreshTimer) {
      clearTimeout(refreshTimer);
    }
    // revoke refresh token on server
    if (currentRefresh) {
      try {
        await axios.post(`${API_BASE_URL}/api/auth/logout`, {
          refreshToken: currentRefresh,
        });
      } catch {}
    }
  };

  const submitInspection = async () => {
    if (!plate) {
      Alert.alert('Validación', 'Debe ingresar la placa del vehículo');
      return;
    }
    try {
      await axios.post(
        `${API_BASE_URL}/api/inspections`,
        { vehicle: { connect: { plate } }, notes },
        { headers: token ? { Authorization: `Bearer ${token}` } : undefined }
      );
      Alert.alert('Éxito', 'Inspección registrada');
      setPlate('');
      setNotes('');
    } catch (err) {
      Alert.alert('Error', err.response?.data?.message || 'No se pudo enviar la inspección');
    }
  };

  const submitAccident = async () => {
    if (!plate || !accDescription) {
      Alert.alert('Validación', 'Placa y descripción son obligatorias');
      return;
    }
    try {
      await axios.post(
        `${API_BASE_URL}/api/accidents`,
        { vehicle: { connect: { plate } }, description: accDescription, severity: accSeverity },
        { headers: token ? { Authorization: `Bearer ${token}` } : undefined }
      );
      Alert.alert('Éxito', 'Accidente registrado');
      setPlate('');
      setAccDescription('');
      setAccSeverity('');
    } catch (err) {
      Alert.alert('Error', err.response?.data?.message || 'No se pudo registrar el accidente');
    }
  };

  // Pantalla de login
  if (!token) {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Iniciar sesión</Text>
        <TextInput
          style={styles.input}
          placeholder="Correo electrónico"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
        />
        <TextInput
          style={styles.input}
          placeholder="Contraseña"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        <Button title="Entrar" onPress={handleLogin} />
      </ScrollView>
    );
  }

  // Pantalla principal con formularios según rol
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={{ marginBottom: 20, width: '100%', alignItems: 'flex-end' }}>
        <Text style={{ marginBottom: 4 }}>Hola, {user?.email} ({user?.role})</Text>
        <Button title="Salir" onPress={logout} color="#ef4444" />
      </View>
      {/* Formulario de inspección visible para todos los roles */}
      <Text style={styles.title}>Inspección Preoperacional</Text>
      <TextInput
        style={styles.input}
        placeholder="Placa del vehículo"
        value={plate}
        onChangeText={setPlate}
      />
      <TextInput
        style={[styles.input, { height: 100 }]}
        multiline
        placeholder="Observaciones / Novedades"
        value={notes}
        onChangeText={setNotes}
      />
      <Button title="Enviar inspección" onPress={submitInspection} />
      {/* Formulario de accidentes solo para SUPERVISOR y MANAGER */}
      {(user?.role === 'SUPERVISOR' || user?.role === 'MANAGER') && (
        <View style={{ marginTop: 40, width: '100%' }}>
          <Text style={styles.title}>Registrar Accidente</Text>
          <TextInput
            style={styles.input}
            placeholder="Descripción del accidente"
            value={accDescription}
            onChangeText={setAccDescription}
          />
          <TextInput
            style={styles.input}
            placeholder="Severidad (Leve, Moderada, Grave)"
            value={accSeverity}
            onChangeText={setAccSeverity}
          />
          <Button title="Enviar accidente" onPress={submitAccident} color="#dc2626" />
        </View>
      )}
      {/* Lista de accidentes y enlaces a PDF */}
      {accidents.length > 0 && (
        <View style={{ marginTop: 40, width: '100%' }}>
          <Text style={styles.title}>Accidentes Recientes (PDF)</Text>
          {accidents.map((acc) => (
            <View key={acc.id} style={{ marginBottom: 10 }}>
              <Text>{new Date(acc.date).toLocaleDateString()} - {acc.description}</Text>
              <Button
                title="Ver reporte PDF"
                onPress={() => {
                  const url = `${API_BASE_URL}/api/reports/accident/${acc.id}`;
                  Linking.openURL(url);
                }}
                color="#3b82f6"
              />
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#f8fafc',
    alignItems: 'center',
    justifyContent: 'flex-start',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
    marginTop: 12,
  },
  input: {
    width: '100%',
    borderColor: '#cbd5e1',
    borderWidth: 1,
    borderRadius: 6,
    padding: 12,
    marginBottom: 12,
    backgroundColor: '#fff',
  },
});