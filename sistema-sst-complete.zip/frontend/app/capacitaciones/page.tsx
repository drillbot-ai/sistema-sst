"use client";
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

interface Capacitacion {
  id: number;
  title: string;
  topic?: string | null;
  date: string;
}

export default function CapacitacionesPage() {
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const limit = 10;
  const { token, user } = useAuth();

  const { data, isLoading, error, refetch } = useQuery<Capacitacion[]>({
    queryKey: ['capacitaciones', page, search],
    queryFn: async () => {
      const res = await axios.get<Capacitacion[]>(
        `http://localhost:3001/api/capacitaciones?limit=${limit}&offset=${page * limit}&search=${encodeURIComponent(
          search,
        )}`,
        token ? { headers: { Authorization: `Bearer ${token}` } } : undefined,
      );
      return res.data;
    },
  });

  return (
    <main className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold">Capacitaciones</h1>
        {user?.role !== 'DRIVER' && (
          <Link
            href="/capacitaciones/new"
            className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
          >
            Nueva capacitación
          </Link>
        )}
      </div>
      <div className="mb-4 flex space-x-2">
        <input
          type="text"
          placeholder="Buscar por título..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-gray-300 rounded px-2 py-1 w-full max-w-xs"
        />
        <button
          onClick={() => setPage(0) || refetch()}
          className="bg-gray-200 px-3 py-1 rounded text-sm"
        >
          Buscar
        </button>
      </div>
      {isLoading && <p>Cargando…</p>}
      {error && <p className="text-red-500">Error al cargar capacitaciones</p>}
      <table className="min-w-full bg-white shadow rounded-md overflow-hidden">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2 text-left">Título</th>
            <th className="px-4 py-2 text-left">Tema</th>
            <th className="px-4 py-2 text-left">Fecha</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((c) => (
            <tr key={c.id} className="border-b">
              <td className="px-4 py-2 font-semibold">{c.title}</td>
              <td className="px-4 py-2">{c.topic || '-'}</td>
              <td className="px-4 py-2">
                {new Date(c.date).toLocaleDateString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 flex space-x-2">
        <button
          onClick={() => setPage((p) => Math.max(0, p - 1))}
          className="bg-gray-200 px-3 py-1 rounded disabled:opacity-50"
          disabled={page === 0}
        >
          Anterior
        </button>
        <span className="px-3 py-1">Página {page + 1}</span>
        <button
          onClick={() => setPage((p) => p + 1)}
          className="bg-gray-200 px-3 py-1 rounded"
        >
          Siguiente
        </button>
      </div>
    </main>
  );
}