"use client";
import Link from 'next/link';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { useState } from 'react';

interface Inspection {
  id: number;
  date: string;
  notes?: string;
  vehicle: { plate: string };
  driver?: { firstName: string; lastName: string };
}

export default function InspectionsPage() {
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const limit = 10;
  const { data, isLoading, error } = useQuery<Inspection[]>({
    queryKey: ['inspections', page, search],
    queryFn: async () => {
      const res = await axios.get<Inspection[]>(
        `http://localhost:3001/api/inspections?limit=${limit}&offset=${page * limit}&search=${encodeURIComponent(search)}`,
      );
      return res.data;
    },
  });
  return (
    <main className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Inspecciones</h1>
      <div className="mb-4">
        <Link href="/inspecciones/new" className="bg-blue-600 text-white px-4 py-2 rounded">
          Nueva inspección
        </Link>
      </div>
      {/* Buscador */}
      <div className="mb-4 flex space-x-2">
        <input
          type="text"
          placeholder="Buscar por placa o notas..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-gray-300 rounded px-2 py-1 w-full max-w-xs"
        />
        <button onClick={() => setPage(0)} className="bg-gray-200 px-3 py-1 rounded text-sm">
          Buscar
        </button>
      </div>
      {isLoading && <p>Cargando…</p>}
      {error && <p className="text-red-500">Error al cargar las inspecciones</p>}
      <table className="min-w-full bg-white shadow rounded-md overflow-hidden text-sm">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2 text-left">Fecha</th>
            <th className="px-4 py-2 text-left">Placa</th>
            <th className="px-4 py-2 text-left">Conductor</th>
            <th className="px-4 py-2 text-left">Notas</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((i) => (
            <tr key={i.id} className="border-b">
              <td className="px-4 py-2">{new Date(i.date).toLocaleDateString()}</td>
              <td className="px-4 py-2 font-semibold">{i.vehicle?.plate}</td>
              <td className="px-4 py-2">
                {i.driver ? `${i.driver.firstName} ${i.driver.lastName}` : '-'}
              </td>
              <td className="px-4 py-2">{i.notes ?? '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* Paginación */}
      <div className="mt-4 flex space-x-2">
        <button
          onClick={() => setPage((p) => Math.max(0, p - 1))}
          className="bg-gray-200 px-3 py-1 rounded disabled:opacity-50"
          disabled={page === 0}
        >
          Anterior
        </button>
        <span className="px-3 py-1">Página {page + 1}</span>
        <button
          onClick={() => setPage((p) => p + 1)}
          className="bg-gray-200 px-3 py-1 rounded"
        >
          Siguiente
        </button>
      </div>
    </main>
  );
}