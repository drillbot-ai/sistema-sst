import './globals.css';
import { ReactNode } from 'react';
import Providers from './providers';
import { AuthProvider } from './context/AuthContext';

export const metadata = {
  title: 'Sistema SG‑SST',
  description: 'Gestión de seguridad y salud en el trabajo para transporte',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body className="bg-gray-100">
        <Providers>
          <AuthProvider>{children}</AuthProvider>
        </Providers>
      </body>
    </html>
  );
}