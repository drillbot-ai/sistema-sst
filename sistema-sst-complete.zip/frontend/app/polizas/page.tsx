"use client";
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

interface Poliza {
  id: number;
  type: string;
  number: string;
  provider?: string | null;
  issueDate: string;
  expiryDate: string;
  value?: number | null;
  vehicle?: { plate: string } | null;
  fileUrl?: string | null;
}

export default function PolizasPage() {
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const limit = 10;
  const { token, user } = useAuth();

  const { data, isLoading, error, refetch } = useQuery<Poliza[]>({
    queryKey: ['polizas', page, search],
    queryFn: async () => {
      const res = await axios.get<Poliza[]>(
        `http://localhost:3001/api/polizas?limit=${limit}&offset=${page * limit}&search=${encodeURIComponent(
          search,
        )}`,
        token ? { headers: { Authorization: `Bearer ${token}` } } : undefined,
      );
      return res.data;
    },
  });

  return (
    <main className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold">Pólizas</h1>
        {user?.role !== 'DRIVER' && (
          <Link
            href="/polizas/new"
            className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
          >
            Nueva póliza
          </Link>
        )}
      </div>
      <div className="mb-4 flex space-x-2">
        <input
          type="text"
          placeholder="Buscar por número o placa..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-gray-300 rounded px-2 py-1 w-full max-w-xs"
        />
        <button
          onClick={() => setPage(0) || refetch()}
          className="bg-gray-200 px-3 py-1 rounded text-sm"
        >
          Buscar
        </button>
      </div>
      {isLoading && <p>Cargando…</p>}
      {error && <p className="text-red-500">Error al cargar pólizas</p>}
      <table className="min-w-full bg-white shadow rounded-md overflow-hidden">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2 text-left">Número</th>
            <th className="px-4 py-2 text-left">Tipo</th>
            <th className="px-4 py-2 text-left">Vehículo</th>
            <th className="px-4 py-2 text-left">Vencimiento</th>
            <th className="px-4 py-2 text-left">Archivo</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((p) => (
            <tr key={p.id} className="border-b">
              <td className="px-4 py-2 font-semibold">{p.number}</td>
              <td className="px-4 py-2">{p.type}</td>
              <td className="px-4 py-2">{p.vehicle?.plate || '-'}</td>
              <td className="px-4 py-2">
                {new Date(p.expiryDate).toLocaleDateString()}
              </td>
              <td className="px-4 py-2">
                {p.fileUrl ? (
                  <a href={p.fileUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
                    Descargar
                  </a>
                ) : (
                  '-'
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 flex space-x-2">
        <button
          onClick={() => setPage((p) => Math.max(0, p - 1))}
          className="bg-gray-200 px-3 py-1 rounded disabled:opacity-50"
          disabled={page === 0}
        >
          Anterior
        </button>
        <span className="px-3 py-1">Página {page + 1}</span>
        <button
          onClick={() => setPage((p) => p + 1)}
          className="bg-gray-200 px-3 py-1 rounded"
        >
          Siguiente
        </button>
      </div>
    </main>
  );
}