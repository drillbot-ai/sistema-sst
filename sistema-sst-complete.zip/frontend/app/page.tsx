"use client";
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import Link from 'next/link';
import { useAuth } from './context/AuthContext';
import { useState } from 'react';

interface Vehicle {
  id: number;
  plate: string;
  brand?: string;
  model?: string;
  year?: number;
  vin?: string;
}

export default function HomePage() {
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const limit = 10;
  const { data, isLoading, error } = useQuery<Vehicle[]>({
    queryKey: ['vehicles', page, search],
    queryFn: async () => {
      const res = await axios.get<Vehicle[]>(
        `http://localhost:3001/api/vehicles?limit=${limit}&offset=${page * limit}&search=${encodeURIComponent(search)}`,
      );
      return res.data;
    },
  });
  const { user, token, logout } = useAuth();
  const navLinks = [
    { href: '/', label: 'Vehículos' },
    { href: '/inspecciones', label: 'Inspecciones' },
    { href: '/mantenimientos', label: 'Mantenimientos' },
    { href: '/accidentes', label: 'Accidentes' },
    { href: '/polizas', label: 'Pólizas' },
    { href: '/capacitaciones', label: 'Capacitaciones' },
    { href: '/contratistas', label: 'Contratistas' },
    { href: '/metrics', label: 'Indicadores' },
  ];
  return (
    <main className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold">Flota de vehículos</h1>
        {token ? (
          <div className="space-x-2">
            <span className="text-sm">{user?.email} ({user?.role})</span>
            <button onClick={logout} className="text-blue-600 underline">Salir</button>
          </div>
        ) : (
          <Link href="/login" className="text-blue-600 underline">Entrar</Link>
        )}
      </div>
      {/* Navigation menu */}
      <nav className="mb-6 flex flex-wrap gap-4 text-sm">
        {navLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
          >
            {link.label}
          </Link>
        ))}
      </nav>
      {/* Buscador */}
      <div className="mb-4 flex space-x-2">
        <input
          type="text"
          placeholder="Buscar por placa..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-gray-300 rounded px-2 py-1 w-full max-w-xs"
        />
        <button
          onClick={() => setPage(0)}
          className="bg-gray-200 px-3 py-1 rounded text-sm"
        >
          Buscar
        </button>
      </div>
      {isLoading && <p>Loading…</p>}
      {error && <p className="text-red-500">Error al cargar vehículos</p>}
      <table className="min-w-full bg-white shadow rounded-md overflow-hidden">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2 text-left">Placa</th>
            <th className="px-4 py-2 text-left">Marca</th>
            <th className="px-4 py-2 text-left">Modelo</th>
            <th className="px-4 py-2 text-left">Año</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((v) => (
            <tr key={v.id} className="border-b">
              <td className="px-4 py-2 font-semibold">{v.plate}</td>
              <td className="px-4 py-2">{v.brand || '-'}</td>
              <td className="px-4 py-2">{v.model || '-'}</td>
              <td className="px-4 py-2">{v.year || '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* Paginación */}
      <div className="mt-4 flex space-x-2">
        <button
          onClick={() => setPage((p) => Math.max(0, p - 1))}
          className="bg-gray-200 px-3 py-1 rounded disabled:opacity-50"
          disabled={page === 0}
        >
          Anterior
        </button>
        <span className="px-3 py-1">Página {page + 1}</span>
        <button
          onClick={() => setPage((p) => p + 1)}
          className="bg-gray-200 px-3 py-1 rounded"
        >
          Siguiente
        </button>
      </div>
    </main>
  );
}