import { test, expect } from '@playwright/test';

test('login page loads and has form elements', async ({ page }) => {
  await page.goto('/login');
  const emailInput = page.locator('input[type="email"]');
  const passwordInput = page.locator('input[type="password"]');
  await expect(emailInput).toBeVisible();
  await expect(passwordInput).toBeVisible();
});